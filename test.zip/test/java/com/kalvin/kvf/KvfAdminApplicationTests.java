package com.kalvin.kvf;

import org.junit.Test;

public class KvfAdminApplicationTests extends BaseJunitTest {

    @Test
    public void contextLoads() {
    }

}
